#!/bin/bash

#### Script para configuração VPN IPSEC para Linux ###

###############################################################################################
#Verificando internet e data/hora

# Colors
COLOR_DEFAULT="\033[0;0m"
COLOR_SUCESS="\033[1;92m"
COLOR_DANGER="\033[1;31m"

CONT_NET=0

checkNet() {
    ping www.google.com -c 5 > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
        echo  -e "${COLOR_SUCESS} ✅ ${COLOR_DEFAULT} Connection Internet"
    else
        if [ ${CONT_NET} -eq 10 ]
        then
            echo
            echo  -e "${COLOR_DANGER} ╦┌┐┌┌┬┐┌─┐┬─┐┌┐┌┌─┐┌┬┐  ┌─┐┌─┐┌┐┌┌┐┌┌─┐┌─┐┌┬┐┬┌─┐┌┐┌  ┌─┐┌─┐┬┬  ┌─┐┌┬┐"
            echo  -e "${COLOR_DANGER} ║│││ │ ├┤ ├┬┘│││├┤  │   │  │ │││││││├┤ │   │ ││ ││││  ├┤ ├─┤││  ├┤  ││"
            echo  -e "${COLOR_DANGER} ╩┘└┘ ┴ └─┘┴└─┘└┘└─┘ ┴   └─┘└─┘┘└┘┘└┘└─┘└─┘ ┴ ┴└─┘┘└┘  └  ┴ ┴┴┴─┘└─┘─┴┘"
            echo
            exit 1
        fi
        echo  -e "${COLOR_DANGER} ❌ ${COLOR_DEFAULT} Connection Internet"
        CONT_NET=$(($CONT_NET+1))
        sleep 3
        checkNet
    fi;
}

checkNet

checkDate() {
##################ATUALIZANDO DATA E HORA
SRV_NTP="a.st1.ntp.br"
PING=1
CONT_NET=0
while [ $CONT_NET -ne 10 ] && [ $PING -eq 1 ]; do               
    ping $SRV_NTP -c 5 > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
	echo  -e "${COLOR_SUCESS} ✅ ${COLOR_DEFAULT} Connection server NTP"
        PING=0
	break
    fi
    echo  -e "${COLOR_DANGER} ❌ ${COLOR_DEFAULT} Connection server NTP"
    CONT_NET=$(($CONT_NET + 1))
    sleep 2 
done
    
if [ $PING -eq 1 ]
then
            echo
            echo  -e "${COLOR_DANGER}   ┌─┐┌─┐┌┐┌┌┐┌┌─┐┌─┐┌┬┐┬┌─┐┌┐┌  ┌─┐┌─┐┬┬  ┌─┐┌┬┐"
            echo  -e "${COLOR_DANGER}   │  │ │││││││├┤ │   │ ││ ││││  ├┤ ├─┤││  ├┤  ││"
            echo  -e "${COLOR_DANGER}   └─┘└─┘┘└┘┘└┘└─┘└─┘ ┴ ┴└─┘┘└┘  └  ┴ ┴┴┴─┘└─┘─┴┘"
            echo
	    while true; do
              read -r -p "A conexão com servidor NTP falhou. Caso continue com a instalação é necessário verificar se data e hora estão corretos. Deseja continuar com a instalação? (S/N): " answer
              case $answer in
                  [Ss]* ) break;;
                  [Nn]* ) exit 1;;
                  * ) echo "Por favor, responda S ou N.";;
              esac
            done
fi

#Instalar systemd-timesync
echo "[Instalando systemd-timesync para serviço de NTP(ajuste da data/hora]"
apt update > /dev/null 2>&1
apt-get install systemd-timesyncd -y > /dev/null 2>&1

#Definindo o timezone do notebook
#timedatectl set-timezone America/Campo_Grande

#Ativar o ntp
timedatectl set-ntp true

#Adicionando o servidor NTP interno da AZ para atualizar data e hora
sed -i 's/^#NTP=.*/NTP=a.st1.ntp.br/g' /etc/systemd/timesyncd.conf

#Reinicinado o serviço
systemctl restart  systemd-timesyncd.service

sleep 2
}

checkDate

###############################################################################################
#Instalação dos pacotes necessários
#Atualiza o repositório
echo -e "\n[Atualizando repositório...]"
apt update > /dev/null 2>&1
#Instala os pacotes necessários

echo "[Instalando os seguintes pacotes:openssh-server, python3, openssl, ansible, vim, curl e sshpass]"
apt-get install -y\
        	openssh-server\
		python3\
	       	python3-pip\
		python3-tk\
		openssl\
	       	ansible\
	       	vim\
	       	curl\
		libssl-dev\
	       	build-essential\
		libappindicator1\
		sshpass > /dev/null 2>&1

###############################################################################################
#Variaveis
#Variaiveis para baixar código do git
URL="http://qualidade.azi.net.br/vpn/vpn-ipsec-linux-main.tar.gz"
FILE_NAME="vpnipsec.tar.gz"

###############################################################################################
#Define a pasta do projeto
PROJECTS=/tmp/Projects
FOLDER_NAME="vpn-ipsec-linux-main"
mkdir $PROJECTS
###############################################################################################
#Variavel para criação do usuário
USER1=("sysadmin" "Admin of System")

AUTHORIZED_KEYS="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQCx6K0tUd5j6d7rNDZAMDxFjQeQWFsPiBOHlwFM/Lj/grchzPM8zXirl3t47csiEZg3dhJhbORTI6DkFTwR1oJ2y3OuwRUd+pF0HyEQvHNw4XgQ1fBCgrINI4XSkaBTFwoA3RM8+8YaQeQ7Qutew1QO5N0mgA6yShj4ZDPcWRgIEwjjcmee3xOtUMe6cYmhO+dL9JEnbAApL1bqCQgWLQkZh/0uGMKD3mNnvCN+DUnuMuI0NajumC0SgjA6PgX5mrqdCrBZpF0cP01FxWCIDGoQ++3ylxgs/WznH35XHdK3qKVOLBWvPQDNPDjMzNaxche4sZspYguePRVoBOhUiYeiqNYlaXjPTChlPsGKp/qvw4eTFWxZF+zQgzS6oBdGa/0pbxv9qnYk6eIkt+UdAVGI4qcNF491AuzedXzXOGkFXuBS6Ib7862qYVgmHOhizUGce0fXXPQtgmajB1THZnKTl2n5XCEL0G3BTWekkdfPy/f2n+SLnctqJ4FFDrUq2PUMR0/iNnPoiGxkmhi4L2CbACj/GnX+vr/oKE2xvLOsXRyGvzBRtxfJ4INbktfwW4fkqqS7etiQ9K+fQXj46lx4gpenLZPGolTAxO8Zn3XMIUl1805VhyEnYEhJ7iN+hW3s0ya769/5PIA7Ner92Whhyj9xqK0Ao2h3Fm1yYg6eCw== az@azn00001"

#Criação do usuário para automação

echo "[Criando usuário Sysadmin para automação]"

getent passwd ${USER1[0]} > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "Usuário SysAdmin já está criado."
else
    useradd -m -d /home/${USER1[0]} -s /bin/bash -c "${USER1[1]}" ${USER1[0]}
    mkdir -p /home/${USER1[0]}/.ssh
    echo $AUTHORIZED_KEYS > /home/$USER1/.ssh/authorized_keys 
    chown -R ${USER1[0]}:${USER1[0]} /home/${USER1[0]}
    chmod -R 755 /home/${USER1[0]}/    
    echo "${USER1[0]} ALL = (ALL) NOPASSWD:ALL" >> /etc/sudoers.d/${USER1[0]}
fi

###############################################################################################

#Download dos arquivos do projeto

echo "[Download do arquivo de configurações]"
curl $URL -o $PROJECTS/$FILE_NAME

if [ $? -ne 0 ]; then
	echo "Download não realizado. Verifique se o arquivo existe."
	exit
fi

IS_HTML=$(file $PROJECTS/$FILE_NAME | cut -d: -f2 | cut -d' ' -f2)
if [ $IS_HTML == "HTML" ]; then
	echo "Arquivo não está na pasta. Verifique se o download foi bem sucedido."	
	exit
fi

tar -xzf $PROJECTS/$FILE_NAME  -C $PROJECTS/
#mv $PROJECTS/templatelinux-main $PROJECTS/$FOLDER_NAME
rm -f $PROJECTS/$FILE_NAME
chmod 600 $PROJECTS/$FOLDER_NAME/id_rsa
###############################################################################################


###############################################################################################
#Configura o arquivo do Ansible
ANSIBLE="/etc/ansible"

#Cria a pasta /etc/ansible caso não exista
if [ ! -d "$ANSIBLE" ]; then
  mkdir -p /etc/ansible
  touch /etc/ansible/{hosts,ansible.cfg}
  echo -e "[defaults]\n#host_key_checking = False" >> /etc/ansible/ansible.cfg
fi 

#Copia de segurança dos arquivos
cp /etc/ansible/hosts /etc/ansible/hosts.bkp
cp /etc/ansible/ansible.cfg /etc/ansible/ansible.cfg.bkp

#Altera o /etc/ansible/ansible.cfg para não efetuar trocar de chaves
sed -i 's/^#host_key_checking =.*/host_key_checking = False/' /etc/ansible/ansible.cfg

#Verifica se a entrada desse host [vpnipsec] já existe no arquivo /etc/ansible/hosts
grep -E '^\[vpnipsec\]' /etc/ansible/hosts > /dev/null

if [ $? -ne 0 ]; then
	echo -e "\n[vpnipsec]\nlocalhost ansible_python_interpreter=/usr/bin/python3 ansible_ssh_private_key_file=$PROJECTS/$FOLDER_NAME/id_rsa" >> /etc/ansible/hosts
fi

##############################################################################################
#Habilitar somente para testes
#Testa se o ansible está funcionando
#Usado somenta para debug em caso de falhas
#ansible -m ping notebook --become-method sudo --become-user az --ask-vault-pass -u az -k


###############################################################################################
#Inicio da playbook do ansible - VPNIPSEC
echo -e "\nInicio da playbook do ansible - VPNIPSEC"
sleep 2
ansible-playbook $PROJECTS/$FOLDER_NAME/project.yaml

if [ $? -ne 0 ];then
   echo -e "Ocorreu um erro na execução do script. Procure a equipe infra para mais informações."
   rm -rf $PROJECTS/*
   exit 1
fi


echo -e "\nFim da playbook do ansible - VPNIPSEC"
sleep 2
###############################################################################################

###############################################################################################
#Inicio da playbook do ansible - GET INFORMATION
echo -e "\nInicio da playbook do ansible - GET INFORMATION"
sleep 2
ansible-playbook $PROJECTS/$FOLDER_NAME/get_information/project.yaml

if [ $? -ne 0 ];then
   echo -e "Ocorreu um erro na execução do script. Procure a equipe infra para mais informações."
   rm -rf $PROJECTS/*
   exit 1
fi

echo -e "\nFim da playbook do ansible - GET INFORMATION"
sleep 2

###############################################################################################
#Deletando todo o projeto
rm -rf $PROJECTS/*

###############################################################################################
#Executando o get information
/etc/ikec/get_information/start.sh


###############################################################################################

###############################################################################################

#Alterando o servidor de NTP para o disponível pela Internet para assim funcionar na casa do colaborador
sed -i 's/^#NTP=.*/NTP=a.st1.ntp.br,b.st1.ntp.br,c.st1.ntp.br/g' /etc/systemd/timesyncd.conf

#Reinicinado o serviço
systemctl restart  systemd-timesyncd.service

###############################################################################################
echo "Por favor, Reinicie para que as configurações tenham efeito."
sleep 2
