#!/bin/bash

# Colors
COLOR_DEFAULT="\033[0;0m"
COLOR_SUCESS="\033[1;92m"
COLOR_DANGER="\033[1;31m"

CONT_NET=0

checkNet() {
    ping www.google.com -c 5 > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
        echo  -e "${COLOR_SUCESS} ✅ ${COLOR_DEFAULT} Connection Internet"
    else
        if [ ${CONT_NET} -eq 10 ]
        then
            echo
            echo  -e "${COLOR_DANGER} ╦┌┐┌┌┬┐┌─┐┬─┐┌┐┌┌─┐┌┬┐  ┌─┐┌─┐┌┐┌┌┐┌┌─┐┌─┐┌┬┐┬┌─┐┌┐┌  ┌─┐┌─┐┬┬  ┌─┐┌┬┐"
            echo  -e "${COLOR_DANGER} ║│││ │ ├┤ ├┬┘│││├┤  │   │  │ │││││││├┤ │   │ ││ ││││  ├┤ ├─┤││  ├┤  ││"
            echo  -e "${COLOR_DANGER} ╩┘└┘ ┴ └─┘┴└─┘└┘└─┘ ┴   └─┘└─┘┘└┘┘└┘└─┘└─┘ ┴ ┴└─┘┘└┘  └  ┴ ┴┴┴─┘└─┘─┴┘"
            echo
            exit 1
        fi
        echo  -e "${COLOR_DANGER} ❌ ${COLOR_DEFAULT} Connection Internet"
        CONT_NET=$(($CONT_NET+1))
        sleep 3
        checkNet
    fi;
}

#checkNet


checkDate() {
##################ATUALIZANDO DATA E HORA
SRV_NTP="10.100.10.12"
PING=1
CONT_NET=0
while [ $CONT_NET -ne 10 ] && [ $PING -eq 1 ]; do               
    ping $SRV_NTP -c 5 > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
	echo  -e "${COLOR_SUCESS} ✅ ${COLOR_DEFAULT} Connection servidor NTP($SRV_NTP)"
        PING=0
	break
    fi
    echo  -e "${COLOR_DANGER} ❌ ${COLOR_DEFAULT} Connection servidor NTP($SRV_NTP)"
    CONT_NET=$(($CONT_NET + 1))
    sleep 2 
done
    
if [ $PING -eq 1 ]
then
            echo
            echo  -e "${COLOR_DANGER}   ┌─┐┌─┐┌┐┌┌┐┌┌─┐┌─┐┌┬┐┬┌─┐┌┐┌  ┌─┐┌─┐┬┬  ┌─┐┌┬┐"
            echo  -e "${COLOR_DANGER}   │  │ │││││││├┤ │   │ ││ ││││  ├┤ ├─┤││  ├┤  ││"
            echo  -e "${COLOR_DANGER}   └─┘└─┘┘└┘┘└┘└─┘└─┘ ┴ ┴└─┘┘└┘  └  ┴ ┴┴┴─┘└─┘─┴┘"
            echo
	    while true; do
              read -r -p "A conexão com servidor NTP falhou. Caso continue com a instalação é necessário verificar se data e hora estão corretos. Deseja continuar com a instalação? (S/N): " answer
              case $answer in
                  [Ss]* ) break;;
                  [Nn]* ) exit 1;;
                  * ) echo "Por favor, responda S ou N.";;
              esac
            done
fi

#Definindo o timezone do notebook
timedatectl set-timezone America/Campo_Grande

#Ativar o ntp
timedatectl set-ntp true

#Adicionando o servidor NTP interno da AZ para atualizar data e hora
sed -i 's/^#NTP=.*/NTP=10.100.10.12/g' /etc/systemd/timesyncd.conf

#Reinicinado o serviço
systemctl restart  systemd-timesyncd.service

sleep 2
}

#checkDate
