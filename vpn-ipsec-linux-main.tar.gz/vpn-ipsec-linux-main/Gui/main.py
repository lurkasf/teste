import PySimpleGUI as sg
from subprocess import Popen, PIPE, STDOUT
from datetime import datetime
import time

class TelaShrew:
    def __init__(self):
        sg.theme('Reddit')
        self.path_log = "/tmp/ikec.log"
        #Layout
        layout = [
            [sg.Image('/etc/ikec/sites/vpn-image3.png')],
            [sg.Text('VPN Type',size=(10,0)),sg.Text('VPN IP-SEC',size=(30,0),justification='c')],
            [sg.Text('Username',size=(10,0)),sg.Input(size=(30,0),key="username",justification='center')],
            [sg.Text('Password',size=(10,0)),sg.Input(size=(30,0),key="password",password_char='*', do_not_clear=False,justification='center')],
            
            [   sg.Push(),#Serve para centralizar horizontalmente os elementos que estão entre eles. Preciso do sg.Push() no fim tbm
                sg.pin(sg.Button('Connect',bind_return_key=True)),# bind_return_key=True habilita o enter do teclado
                sg.pin(sg.Button('Disconnect', visible=False)),
                sg.pin(sg.Button('Informações da Conexão', size=(20,0), visible=False, key="info")),
                sg.pin(sg.Button('Cancel')),
                sg.Push()# Esse aqui fecha os elementos que devem ser centralizados
            ]#,
            #[sg.Output(size=(40,20))]
        ]
        #Janela        
        self.janela = sg.Window("VPN AZ", layout, finalize=True, icon='/etc/ikec/sites/vpn-image4.png')
    
    def Iniciar(self):       
        control = -1 # Controla se houve conexão com a VPN
        aux = -1 # Controla se houve uma desconexão
        data_hora = None
        tempo = None # Controla a duração da conexão                
        while True:
            #Extrair os dados da tela            
            self.events, self.values = self.janela.Read()            
            if self.events == 'Connect':                
                username = self.values['username']
                password = self.values['password']
                valid_username = self.is_blank(username)
                valid_password = self.is_blank(password)
                if valid_username and valid_password:
                    #print (f"nome: {username} / password: {password}")
                    time.sleep(0.5) # Esepro esse tempo, as vezes o cara pode clicar muito em conectar e desconectar e pode dar problema
                    control = self.execute(username,password) # Se a conexão falhar a função retorna False e não -1
                    if control is not False:                    
                        self.janela['Connect'].Update(visible=False)# nem todas as opções de criação, são válidas para o Update
                        self.janela['Connect'].BindReturnKey = False# Ess opção não está disponivel no UPdate, por isso coloquei assim. Aqui desabilita o enter
                        self.janela['Cancel'].Update(visible=False)
                        self.janela['Disconnect'].Update(visible=True)
                        self.janela['Disconnect'].BindReturnKey = True
                        self.janela['info'].Update(visible=True)
                        data_hora = datetime.now()
                        tempo = time.time()
                        self.log(status = "ON", inicio_conn = data_hora)
                        sg.popup_ok('Tunnel enabled. Success connection. Enjoy!!!!!', title="Success connection")
                    else:
                        sg.popup_ok('Authentication failed. Try again.', title="Window Authentication.")
                else:                    
                    sg.popup_ok('The fields username and password must be filled.', title="Validation Field")
            elif self.events == sg.WINDOW_CLOSED:                
                time.sleep(0.5)
                if control != -1:
                    control.kill()
                    self.log(status = "OFF")
                    data_hora = None
                    tempo = None  
                break 
            elif self.events == 'Cancel':
                #print("Apertou em Cancel")
                break 

            elif self.events == 'Disconnect':
                out = sg.popup_yes_no('Are you sure disconnect?', title="Window Disconnect.")                               
                if out == 'Yes':
                    time.sleep(0.5)
                    self.janela['Disconnect'].Update(visible=False)
                    self.janela['Disconnect'].BindReturnKey = False
                    self.janela['info'].Update(visible=False)
                    self.janela['Connect'].Update(visible=True)
                    self.janela['Connect'].BindReturnKey = True
                    self.janela['Cancel'].Update(visible=True)
                    self.log(status = "OFF")  
                    data_hora = None
                    tempo = None            
                    control.kill() 
            
            elif self.events == 'info':
                end = time.time()
                duration = end - tempo                
                msg = f"""                    
                    IP: {self.get_ip()}
                    Username: {self.values['username']}
                    Date/Hour Connection: {data_hora.strftime('%d/%m/%Y %H:%M')}
                    Duration: {time.strftime("%H:%M:%S", time.gmtime(duration))}
                """
                sg.popup_ok(f'{msg}',title="Informations")               
    
    def is_blank(*args):        
        if len(args[1]) == 0:
            return 0       
        return 1                        
    
    def kill_process_ikec(*args,**kwargs):
        cmd = ["killall","ikec"]
        print("\nVerifica se existe processo do IKEC em execução.")
        try:            
            exec = Popen(cmd,stdout=PIPE,stderr=STDOUT,stdin=PIPE,universal_newlines=True)
            while exec.poll() == None:
                text = exec.stdout.readline()                   
                print(text)                

        except Exception as e:
            print("Erro ao executar o comando.",e)                     

    def execute(self,username,password):        
        aux = 0
        self.kill_process_ikec()# Mata os processos do ikec caso algum esteja aberto, antes de fazer a conexão
        cmd = ["ikec","-r","shrew_conf_ipsec_az","-u",f"{username}","-p",f"{password}","-a"]
        #cmd = [f"ikec -r VPN-IPSEC-LINUX-SHREW -u {username} -p {password} -a"]
        try:            
            exec = Popen(cmd,stdout=PIPE,stderr=STDOUT,stdin=PIPE,universal_newlines=True)
            while exec.poll() == None:
                text = exec.stdout.readline()                   
                print(text)
                if 'tunnel enabled' in text:
                    print("#################### Acesso permitido ####################")
                    aux = 1 # Significa que deu certo o acesso                    
                    break
                
                if 'user authentication error' in text:
                    print("#################### Autenticação Falhou ####################")                    
                    exec.terminate()
                    exec.kill()
                    break                                                            

        except Exception as e:
            print("Erro ao executar o comando.",e)                     
        if aux:
            return exec
        return False  
    
    def get_ip(self):
        cmd = ["ip a s | grep -E 'inet' | sed 's/^[ \t]*//' | cut -d' ' -f2 | cut -d'/' -f 1 | grep -E '^10\.212\.135'"]
        try: 
            exec = Popen(cmd,stdout=PIPE,stderr=STDOUT,stdin=PIPE,shell=True)
            while exec.poll() == None:
                pass               
            ip = exec.communicate(timeout=15)[0].decode('UTF-8')            
        except Exception as e:
            print("Erro ao executar o comando.",e)
        return ip.strip()

    def log(self,*args,**kwargs):        
        if kwargs.get('status',None) == "ON":
            print(f"Usuário: {self.values['username']}")            
            print(f"IP: {self.get_ip()}")
            print(f"Início da Conexão: {kwargs.get('inicio_conn',None).strftime('%d/%m/%Y %H:%M')}")            
            msg = f""" 
#######################CONNECTION#################################################################                   
                    IP: {self.get_ip()}
                    Username: {self.values['username']}
                    Início: {kwargs.get('inicio_conn',None).strftime('%d/%m/%Y %H:%M')}                   
                """
            with open(self.path_log,'a') as f:
                f.write(msg)
        

        if kwargs.get('status',None) == "OFF":
            print(f"Fim da Conexão: {datetime.now().strftime('%d/%m/%Y %H:%M')}")            
            msg = f"""
                    Fim: {datetime.now().strftime('%d/%m/%Y %H:%M')}
#######################DISCONNECT################################################################# 
\n
                """
            with open(self.path_log,'a') as f:
                f.write(msg)
        
        
tela = TelaShrew()
tela.Iniciar()
