#!/bin/bash

source  /etc/ikec/sites/.venv/bin/activate
python3 /etc/ikec/sites/main.py
deactivate
