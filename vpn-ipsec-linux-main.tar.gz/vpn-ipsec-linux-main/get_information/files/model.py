
class ModelPeople:

    def __init__(self):
        self._person = {
                'full_name':'',
                'login_vpn':'',
                'login_local':'',
                'service_tag':'',
                'hostname':'',   
                'platform':'',             
                'created_at':'',
                'updated_at':''
        }

    @property
    def p_person(self):
        return self._person
    
    @p_person.setter
    def p_person(self,person):              
        self._person['full_name']      = person[0]
        self._person['login_vpn']      = person[1]        
        self._person['login_local']     = person[2]        
        self._person['service_tag']    = person[3]
        self._person['hostname']       = person[4]
        self._person['platform']       = person[5]
        self._person['created_at']     = person[6]
        self._person['updated_at']     = person[7]


        
    
