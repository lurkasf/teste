import PySimpleGUI as sg
from crud import Crud
import os

class ExtractData:
    def __init__(self):
        #Link do Firebase
        url = "https://getdataequipamentaz-default-rtdb.firebaseio.com/AZ"
        uri = "/People"
        self.link = f"{url}{uri}"
        sg.theme('Reddit') 
        self.path_images = '/etc/ikec/get_information/'
        #self.path_images = ''            
        msg = ""
        #Layout
        layout = [                 
            [sg.Text('Selecione a pasta para extrair as informações')],
            [sg.Input(key='input'),sg.FolderBrowse(key='browse')], # O folder browse tem que ficar do lado do Input, senão, não funciona
            [sg.Text('_'*45)],#Separador horizontal
            [sg.Text('Selecione o formato')],
            [sg.Radio('csv', "RADIO1", default=True, key="csv"), sg.Radio('xlsx', "RADIO1", key="xlsx")], # radio button retorna true ou false
            [sg.OK(),sg.Button('Fechar')]           
        ]
        #Janela       
        icon = f"{self.path_images}icon_main.png"
        self.janela = sg.Window("Extração das Informações", layout, finalize=True, icon=icon, size=(450,200))
            
    def Iniciar(self):                
        fmt = ''
        while True:
            #Extrair os dados da tela            
            self.events, self.values = self.janela.Read()            
            if self.events == 'OK':               
                location = self.values['input']                
                msg1 , valid_location = self.is_blank(location)
                msg2 , valid_path_location = self.valid_path(location)             
                if valid_location:
                    if valid_path_location:                    
                        msg = "Tem certeza?"                    
                        out = sg.popup(msg, title="Confirme as informações", icon = f"{self.path_images}question.png", custom_text = ('Sim', 'Não'))
                        if out == 'Sim':                                                                        
                            send = Crud(self.link) 
                            fmt = self.get_format()                   
                            save = send.get_data_format(fmt,location)                
                            if save:
                                sg.popup_ok("Arquivo salvo com sucesso.", title=f"{self.path_images}Successo", icon=f"{self.path_images}success.png")
                            else:
                                sg.popup_ok("Ocorreu um erro ao salvar o arquivo. Tente novamente.", title="Validação", icon=f"{self.path_images}alert.png")                        
                    else:                    
                        sg.popup_ok(f"{msg2}", title="Validação", icon=f"{self.path_images}alert.png")
                else:                    
                    sg.popup_ok(f"{msg1}", title="Validação", icon=f"{self.path_images}alert.png")
            elif self.events == sg.WINDOW_CLOSED:
                break           
            elif self.events == 'Fechar':                
                break
                
    
    def is_blank(*args):        
        msg = "O(s) campos(s) devem ser preenchido(s)."
        if len(args[1]) == 0:
            return msg, False 
        msg = ''
        return msg, True

    def get_format(self):        
        if self.values["csv"]:
            return 'csv'
        return 'xml'
    
    def valid_path(self,path):
        msg = "O caminho informado não existe."
        if os.path.exists(path):
            if os.path.isdir(path):
                msg = ''
                return msg, True
            msg = "O caminho informando não é um diretório."
            return msg, False        
        return msg, False

tela = ExtractData()
tela.Iniciar()
