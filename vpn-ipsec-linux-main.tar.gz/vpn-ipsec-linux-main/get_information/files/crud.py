import requests
from requests.structures import CaseInsensitiveDict
import json
import pandas as pd
import os

class Crud:

    def __init__(self,link):
        self.link = link
        #headers = CaseInsensitiveDict()
        self.headers = {
            #"Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type",
            "Origin": "https://www.azi.com.br",
            "Accept": {'Accept':'*/*', 'X-User-IP': '1.1.1.1'},
            "User-Agent": "Python Client/1.0"
        }
        

    def post(self, data=None):
        result = 0
        if data:            
            try:
                res = requests.post(f'{self.link}/.json', data=json.dumps(data))
            except Exception as e:
                print("Erro",e.args)
            if self.status_code(res) == "success":
                print("TODA A REQUISIÇÃO", res.json())
                result = 1
                return result,res
            

    def get(self,*args,**kwargs):
        res = None
        if kwargs['params']:
            params = kwargs['params']
            try:                             
                res = requests.get(f'{self.link}/.json',params=params)
                #print(res.url)
            except Exception as e:
                print("Erro",e.args)            
        else:
            try:
                res = requests.get(f'{self.link}/.json')
            except Exception as e:
                print("Erro",e.args)
        
        if self.status_code(res) == "success":
            #print("TODA A REQUISIÇÃO", res.json())
            return res                

    def patch(self,field = None,data_old = None,data_new = None):
        if field and data_new and data_old:
            ids = self.search(field,data_old)  
            if len(ids) > 0:          
                try:
                    for id in ids:
                        res = requests.patch(f'{self.link}/{id}/.json', data=json.dumps(data_new))
                except Exception as e:
                    print("Erro",e.args)
                if self.status_code(res) == "success":
                    print("TODA A REQUISIÇÃO", res)
                return res
            else:
                print("Não houve alteração.")

    def options(self):
        try:
            res = requests.options(f'{self.link}/.json')
        except Exception as e:
            print("Erro",e.args)
        if self.status_code(res) == "success":
            print("TODA A REQUISIÇÃO", res.text)
        return res

    def delete(self,field = None,data = None):
        if field and data:
            ids = self.search(field,data)  
            if len(ids) > 0:                
                    try:
                        for id in ids:
                            res = requests.delete(f'{self.link}/{id}/.json')
                    except Exception as e:
                        print("Erro",e.args)
                    if self.status_code(res) == "success":
                        print("TODA A REQUISIÇÃO", res)
                    return res
            else:
                print("Não houve alteração.")

    def put(self,uid):
        pass

    def head(self,uid):
        pass    
    

    def status_code(self, res):
        #print("status code", type(res.status_code))
        #if res.status_code != 200 or res.status_code != 204:
        if res.status_code != 200:
            return res.status_code
        
        return "success"

    def search(self,field,data):
        req_get = self.get(params=None)
        dic_req_get = req_get.json()        
        id = []
        aux = None
        for search_id in dic_req_get:
            #print("search_id: ",search_id)
            aux = dic_req_get[search_id][field]
            if aux == data:                
                #print("Search: ",aux)
                #print("Search: ",search_id)
                id.append(search_id)       
        return id
    
    def validate_exists(self, field, data):
        val = list()
        val = self.search(field,data)
        if len(val):
            return True
        return False    
    
    def get_data_format(self,fmt,path):
        marc = 0
        req_get = self.get(params=None)
        dic_req_get = req_get.json()         
        ff = [j for i,j in dic_req_get.items()] # Retira o ID que vem do firebase para ler direto no dataframe                
        df = pd.DataFrame(ff)
        #df.to_csv(os.path.join(os.getcwd(),'data.csv'), index=False)        
        if fmt == 'csv':
            try:
                df.to_csv(os.path.join(path,'data.csv'), index=False)
                marc = 1
            except Exception as e:
                print("Erro ao salvar o arquivo",e) 
        else:
            try:
                df.to_excel(os.path.join(path,'data.xlsx'), index=False)      
                marc = 1
            except Exception as e:
                print("Erro ao salvar o arquivo",e)
        return marc
            
               

    
