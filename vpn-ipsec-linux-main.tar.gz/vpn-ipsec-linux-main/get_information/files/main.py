'''
Pacotes
requests
PySimpleGUI
pandas
openpyxl para o excel
pyinstaller
'''

import PySimpleGUI as sg
from subprocess import Popen, PIPE, STDOUT
from datetime import datetime
from model import ModelPeople
from crud import Crud
import os
import sys
import socket
from subprocess import Popen, PIPE, STDOUT
import platform

class DataEquipamentAZ:
    def __init__(self):
        #Link do Firebase
        url = "https://getdataequipamentaz-default-rtdb.firebaseio.com/AZ"
        uri = "/People"
        self.link = f"{url}{uri}"
        sg.theme('Reddit')
        #msg = "AZTECHs, as informações solicitadas são para a equipe infra mantenha o controle dos equipamentos."
        msg = "Olá, AZTECH! O Team Infra está sempre em melhoria contínua e pede a você que nos ajude fornecendo algumas informações para que possamos continuar trazendo novidades para nosso colaboradores. A sua colaboração é muito importante. As novidades não param!!!!"
        self.path_images = '/etc/ikec/get_information/'
        #self.path_images = ''
        image_name = f"{self.path_images}frente.png"
        #Layout
        layout = [     
            [sg.Image(image_name,size=(370,215))],   
            [sg.Text(msg,size=(50,0),justification='c')],
            [sg.Text('Nome Completo',size=(20,0)),sg.Input(size=(30,0),key="full_name",justification='center')],
            [sg.Text('Login da VPN',size=(20,0)),sg.Input(size=(30,0),key="user_name",justification='center')],            
            
            [   sg.Push(),#Serve para centralizar horizontalmente os elementos que estão entre eles. Preciso do sg.Push() no fim tbm
                sg.pin(sg.Button('Enviar',bind_return_key=True)),# bind_return_key=True habilita o enter do teclado               
                sg.pin(sg.Button('Cancelar')),
                sg.Push()# Esse aqui fecha os elementos que devem ser centralizados
            ]#,
            #[sg.Output(size=(40,20))]
        ]
        #Janela       
        icon = f"{self.path_images}icon_main.png"
        self.janela = sg.Window("Informações", layout, finalize=True, icon=icon)
            
    def Iniciar(self):        
        while True:
            #Extrair os dados da tela            
            self.events, self.values = self.janela.Read()            
            if self.events == 'Enviar':
                full_name = self.values['full_name']
                user_name = self.values['user_name']                
                valid_user_name = self.is_blank(user_name)
                valid_full_name = self.is_blank(full_name)                
                if valid_user_name and valid_full_name:
                    data = self.get_informations(full_name=full_name,user_name=user_name)
                    #print("Valores de data: ",data)
                    msg = f"Confirme as informações:\n {self.format_msg(data)}"                    
                    out = sg.popup(msg, title="Confirme as informações", icon = f"{self.path_images}question.png", custom_text = ('Sim', 'Não'))
                    if out == 'Sim':                                                
                        send = Crud(self.link)
                        val = send.validate_exists('login_vpn', user_name)
                        if val is False: #Retorna False senão tiver sido cadastrado
                            result, response = send.post(data)
                            if result:       
                                msg = 'Informações enviadas com sucesso.\nObrigado por sua colaboração.'   
                                sg.popup_ok(msg, title="Successo", icon=f"{self.path_images}success.png")
                                break
                            else:
                                sg.popup_ok('Falha no envio das informações.', title="Alerta", icon=f"{self.path_images}alert.png")
                        
                        sg.popup_ok('Falha no envio das infrormações.\nO login vpn já foi cadastrado.\nDúvidas, entre em contato com a equipe Infra.', title="Alerta", icon=f"{self.path_images}alert.png")
                    
                else:                    
                    sg.popup_ok('Todos os campos devem estar preenchidos.', title="Validação", icon=f"{self.path_images}alert.png")
            elif self.events == sg.WINDOW_CLOSED:
                break
            elif self.events == 'Cancelar':
                out = sg.popup('Tem certeza?', title="Fechar", icon=f"{self.path_images}question.png", custom_text = ('Sim', 'Não'))
                if out == 'Sim':
                    break
                
    
    def is_blank(*args):        
        if len(args[1]) == 0:
            return 0       
        return 1
    
    def format_msg(self, msg):        
        new_msg = f'''
        Nome Completo  => {msg["full_name"]}\n
        Login VPN      => {msg["login_vpn"]}\n
        Login Local    => {msg["login_local"]}\n
        Service Tag    => {msg["service_tag"]}\n
        Hostname       => {msg["hostname"]}\n
        Plataforma     => {msg["platform"]}\n
        Criado em      => {msg["created_at"]}\n
        Atualizado em  => {msg["updated_at"]}\n
        \n
        Confirma?
        '''
        #print(new_msg)
        return new_msg

    def get_hostname(self):
        return socket.gethostbyaddr(socket.gethostname())[0]

    def get_service_tag(self):        
        st = ''
        so = self.get_so()
        if so == 'linux':            
            cmd1 = ["sudo","dmidecode", "-s", "system-serial-number"]
            cmd2 = ["sudo","dmidecode", "-s", "system-manufacturer"]
            st = f"{self.execute(cmd2)} - {self.execute(cmd1)}"
            
        elif so == 'win32':
            cmd1 = ["wmic", "bios", "get", "serialnumber"]
            cmd2 = ["wmic", "csproduct", "get", "vendor"]
            st = "{} - {}".format(self.execute(cmd2).split('\n')[1], self.execute(cmd1).split('\n')[1])
            #oo = self.execute(cmd2).split("\n")[1]
            #print("Valor de OO", oo)
            #aa = self.execute(cmd1).split("\n")[1]
            #print("Valor de AA", aa)
        else:
            print("Não é linux e nem windows")
            cmd = False        
        return st

    def get_so(self):
        return sys.platform
    
    def get_login_local(self):
        return os.getlogin()

    def get_platform(self):
        plat = ""
        so = self.get_so()        
        if so == 'linux':
            #cmd = ["cat", "/etc/os-release"]
            cmd_name = ["cat /etc/os-release | grep '^NAME=' | cut -d= -f2"]
            cmd_version = ["cat /etc/os-release | grep '^VERSION=' | cut -d= -f2"]
            try: 
                exec = Popen(cmd_name,stdout=PIPE,stderr=STDOUT,stdin=PIPE,shell=True)
                while exec.poll() == None:
                    pass               
                name = exec.communicate(timeout=15)[0].decode('UTF-8')            

                exec = Popen(cmd_version,stdout=PIPE,stderr=STDOUT,stdin=PIPE,shell=True)
                while exec.poll() == None:
                    pass               
                version = exec.communicate(timeout=15)[0].decode('UTF-8')            
            except Exception as e:
                print("Erro ao executar o comando2.",e)                
            name = name.replace('"','').strip()
            version = version.replace('"','').strip()
            plat = f"{name} - {version}"

        elif so == 'win32':                      
            plat = "{} - {} / Versão: {}".format(platform.system(), platform.release() ,platform.version())                                    
        else:
            print("Não é linux e nem windows")
            plat = False
        
        return plat    
        
    def ocs_installed(self):
        pass

    def execute(self,cmd):
        out = ""
        if cmd:
            try:            
                exec = Popen(cmd,stdout=PIPE,stderr=STDOUT,stdin=PIPE)
                while exec.poll() == None:
                    pass                                           
                out = exec.communicate(timeout=15)[0].decode('UTF-8')                 
                out = out.strip()
            except Exception as e:
                print("Erro ao executar o comando3.",e)
        print("Saída do comando: ",out)
        return out
    
    def get_informations(self,**kwargs):
        info= {
                'full_name': kwargs['full_name'],
                'login_vpn': kwargs['user_name'],
                'login_local': self.get_login_local(),
                'service_tag': self.get_service_tag(),
                'hostname': self.get_hostname(),  
                'platform': self.get_platform(),                  
                'created_at':datetime.now().strftime('%d/%m/%Y %H:%M'),
                'updated_at':datetime.now().strftime('%d/%m/%Y %H:%M')
        }
        return info

    def save(self):
        pass

    def update(self):
        pass

tela = DataEquipamentAZ()
tela.Iniciar()
