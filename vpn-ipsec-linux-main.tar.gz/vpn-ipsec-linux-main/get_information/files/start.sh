#!/bin/bash

source  /etc/ikec/get_information/.venv/bin/activate
python3 /etc/ikec/get_information/main.py > /dev/null 2>&1
deactivate

